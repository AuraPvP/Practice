/**
 * Contains kit primitives such as KitType and a kit type selection menu
 */
package net.frozenorb.potpvp.kittype;