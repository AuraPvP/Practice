package net.frozenorb.potpvp.match.listener;

public class MatchReplayActionListener {


    // match start = player spawn
    // player move
    // player teleport
    // player item switch
    // equipment update
    // start drinking potion
    // stop drinking potion
    // potion drink sounds
    // entity spawn
    // entity despawn
    // each tick track locations of items
    // player animation
    // pot splash sounds
    // pot splash particles
    // match end = player despawn

    // I want to maintain a map of entity -> match, just so we can lookup all of these without going location -> arena which is intensive
}
