package com.qrakn.morpheus.game

enum class GameState {
    QUEUED,
    STARTING,
    RUNNING,
    ENDED
}