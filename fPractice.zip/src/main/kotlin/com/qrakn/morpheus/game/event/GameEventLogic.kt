package com.qrakn.morpheus.game.event

interface GameEventLogic {
    fun start()
}