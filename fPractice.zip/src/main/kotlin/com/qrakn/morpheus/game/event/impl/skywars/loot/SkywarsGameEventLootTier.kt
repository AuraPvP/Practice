package com.qrakn.morpheus.game.event.impl.skywars.loot

enum class SkywarsGameEventLootTier {
    NORMAL,
    BUFFED,
    GODLY
}