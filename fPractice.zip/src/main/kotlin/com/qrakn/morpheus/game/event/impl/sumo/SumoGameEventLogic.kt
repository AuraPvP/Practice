package com.qrakn.morpheus.game.event.impl.sumo

import com.qrakn.morpheus.game.Game
import com.qrakn.morpheus.game.event.impl.brackets.BracketsGameEventLogic

class SumoGameEventLogic(game: Game) : BracketsGameEventLogic(game)