package net.frozenorb.potpvp.kt.command.data

interface Data