package net.frozenorb.potpvp.kt.scoreboard

class ScoreboardConfiguration(var titleGetter: TitleGetter, var scoreGetter: ScoreGetter)