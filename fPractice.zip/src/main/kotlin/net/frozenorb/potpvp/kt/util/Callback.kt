package net.frozenorb.potpvp.kt.util

interface Callback<T> {

    fun callback(value: T)

}