package net.frozenorb.potpvp.kt.visibility

enum class OverrideAction {
    SHOW,
    NEUTRAL
}
