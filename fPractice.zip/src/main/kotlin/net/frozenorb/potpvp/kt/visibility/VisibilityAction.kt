package net.frozenorb.potpvp.kt.visibility

enum class VisibilityAction {
    HIDE,
    NEUTRAL
}